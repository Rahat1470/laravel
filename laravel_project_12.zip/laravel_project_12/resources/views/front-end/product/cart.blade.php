@extends('front-end.master')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text text-center text-success alert alert-success">Cart Page</h3>
                </div>
                <div class="panel-body">
                    <table class="table table-border">
                        <tr>
                            <th>SI No.</th>
                            <th>Product Name</th>
                            <th>Product Quantity</th>
                            <th>Product Image</th>
                            <th>Action</th>
                        </tr>
                        @php($i=1)
                        @foreach($carts as $cart)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $cart->name }}</td>
                            <td>
                                {!! Form::open(['route'=>'update_qty']) !!}
                                    {!! Form::text('productQuantity',$cart->qty, ['class'=>'form-control','min'=>1]) !!}
                                    {!! Form::hidden('product_id',$cart->rowId, ['class'=>'form-control']) !!}
                                    <input name="qty_submit" type="submit" value="Update" class="btn btn-success btn-xs">
                                {!! Form::close() !!}
                            </td>
                            <td><img height="100" src="{{ asset($cart->options->image) }}" alt="{{ $cart->name }}"></td>
                            <td>
                                <a href="{{ Route('cartDelete',[$cart->rowId,$cart->name]) }}"><button class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button></a>
                            </td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection