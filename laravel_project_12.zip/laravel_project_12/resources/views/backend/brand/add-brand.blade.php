@extends('backend.master')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="text text-center alert alert-success">Add Brand</h2>
                </div>
                <div class="panel-body">
                    {!! Form::open(['route'=>'saveBrand','class'=>'form-horizontal']) !!}
                        @if(Session::get('success'))
                            <p class="text text-center text-success alert alert-success">{{ Session::get('success') }}</p>
                        @endif
                        @if(Session::get('fail'))
                            <p class="text text-center text-danger alert alert-danger">{{ Session::get('fail') }}</p>
                        @endif
                        <div class="form-group">
                            {!! Form::label('brand_name','Brand Name', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('brand_name',old('brand_name'), ['class'=>'form-control']) !!}
                                <span class="text text-danger">{{ $errors->has('brand_name') ? $errors->first('brand_name') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('brand_description','Brand Description', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::textarea('brand_description',old('brand_description'), ['class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('publication_status','Publication Status', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::radio('publication_status',1,true) !!} Published
                                {!! Form::radio('publication_status',0) !!} Unpublished
                                @error('publication_status') <span class="text text-danger">{{ $message }}</span>@enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-9">
                                <input type="submit" value="Save Brand" class="btn btn-success btn-block" name="saveCategory">
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection