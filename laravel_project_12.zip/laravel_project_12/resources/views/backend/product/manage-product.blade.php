@extends('backend.master')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="h3 text text-center alert alert-success">Manage Product</div>
            </div>
            @if(Session::get('success'))
                <p class="text text-center text-success alert alert-success">{{ Session::get('success') }}</p>
            @endif
            @if(Session::get('fail'))
                <p class="text text-center text-danger alert alert-danger">{{ Session::get('fail') }}</p>
            @endif
            @if($products->count() > 0)
            <table class="table table-border">
                <tr>
                    <th>SI No.</th>
                    <th>Product Name</th>
                    <th>Category Name</th>
                    <th>Brand Name</th>
                    <th>Product Image</th>
                    <th>Product Status</th>
                    <th>Action</th>
                </tr>
                @php($i=1)
                @foreach($products as $product)
                <tr>
                    <td>{{ $i++ }}</td>
                    <td>{{ $product->product_name }}</td>
                    <td>{{ $product->category_name }}</td>
                    <td>{{ $product->brand_name }}</td>
                    <td>@if($product->product_image == 'No Image Selected') <span class="text text-danger">No Image Selected</span>@else<img src="{{ asset($product->product_image) }}" height="100" alt="{{ $product->product_name }}">@endif</td>
                    <td>{{ $product->publication_status == 1 ? 'Published' : 'Unpublished' }}</td>
                    <td>
                        @if($product->publication_status == 1)
                            <a href="{{ Route('productStatus',[$product->id,1,$product->product_name]) }}"><button class="btn btn-success"><i class="fa fa-arrow-up" aria-hidden="true"></i></button></a>
                        @else
                            <a href="{{ Route('productStatus',[$product->id,0,$product->product_name]) }}"><button class="btn btn-warning"><i class="fa fa-arrow-down" aria-hidden="true"></i></button></a>
                        @endif
                        <a href="{{ Route('editProduct',[$product->id,$product->product_name]) }}"><button class="btn btn-info"><i class="fas fa-edit"></i></button></a>
                        <a href="{{ Route('productDelete',[$product->id,$product->product_name]) }}"><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                    </td>
                </tr>
                @endforeach
            </table>
            @else
            <h3 class="text text-info alert alert-danger text-center">No Data Found</h3>
            @endif
        </div>
    </div>
</div>
@endsection