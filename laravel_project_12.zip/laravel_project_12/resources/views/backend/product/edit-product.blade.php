@extends('backend.master')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="text text-center alert alert-success">Edit Product</h2>
                </div>
                <div class="panel-body">
                    {!! Form::open(['name'=>'edit_product_form','route'=>'updateProduct','class'=>'form-horizontal','files'=>true]) !!}
                        @if(Session::get('success'))
                            <p class="text text-center text-success alert alert-success">{{ Session::get('success') }}</p>
                        @endif
                        @if(Session::get('fail'))
                            <p class="text text-center text-danger alert alert-danger">{{ Session::get('fail') }}</p>
                        @endif
                        <div class="form-group">
                            {!! Form::label('product_name','Product Name', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('product_name',$product->product_name, ['class'=>'form-control']) !!}
                                {!! Form::hidden('product_id',$product->id, ['class'=>'form-control']) !!}
                                <span class="text text-danger">{{ $errors->has('product_name') ? $errors->first('product_name') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_slug','Product Slug', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('product_slug',$product->product_slug, ['class'=>'form-control','not-allowed']) !!}
                                <span class="text text-danger">{{ $errors->has('product_slug') ? $errors->first('product_slug') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('category_id','Category Name', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                <select name="category_id" id="" class="form-control">
                                    <option disabled>--Select Option--</option>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}">{{ $category->category_name }}</option>
                                    @endforeach
                                </select>
                                <span class="text text-danger">{{ $errors->has('category_id') ? $errors->first('category_id') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('brand_id','Brand Name', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                <select name="brand_id" id="" class="form-control">
                                    <option disabled>--Select Option--</option>
                                    @foreach($brands as $brand)
                                        <option value="{{ $brand->id }}">{{ $brand->brand_name }}</option>
                                    @endforeach
                                </select>
                                <span class="text text-danger">{{ $errors->has('brand_id') ? $errors->first('brand_id') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_price','Product Price', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('product_price',$product->product_price, ['class'=>'form-control']) !!}
                                <span class="text text-danger">{{ $errors->has('product_price') ? $errors->first('product_price') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_quantity','Product Quantity', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('product_quantity',$product->product_quantity, ['class'=>'form-control']) !!}
                                <span class="text text-danger">{{ $errors->has('product_quantity') ? $errors->first('product_quantity') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_image','Product Image', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                @if($product->product_image == 'No Image Selected') <span class="text text-danger">No Image Selected</span>@else<img src="{{ asset($product->product_image) }}" height="100" alt="{{ $product->product_name }}">@endif
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_image','Product Image', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                <input type="file" name="product_image" id="" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_sort_description','Product Sort Description', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::textarea('product_sort_description',$product->product_sort_description, ['class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('product_long_description','Product Long Description', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::textarea('product_long_description',$product->product_long_description, ['class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('publication_status','Publication Status', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::radio('publication_status',1,$product->publication_status == 1 ? true : '' ) !!} Published
                                {!! Form::radio('publication_status',0,$product->publication_status == 0 ? true : '' ) !!} Unpublished
                                @error('publication_status') <span class="text text-danger">{{ $message }}</span>@enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-9">
                                <input type="submit" value="Save Product" class="btn btn-success btn-block" name="saveProduct">
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.forms['edit_product_form'].elements['category_id'].value='{{ $product->category_id }}';
    document.forms['edit_product_form'].elements['brand_id'].value='{{ $product->brand_id }}';
</script>
@endsection
