@extends('backend.master')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="text text-center alert alert-success">Add Category</h2>
                </div>
                <div class="panel-body">
                    {!! Form::open(['route'=>'saveCategory','class'=>'form-horizontal']) !!}
                        @if(Session::get('success'))
                            <p class="text text-center text-success alert alert-success">{{ Session::get('success') }}</p>
                        @endif
                        @if(Session::get('fail'))
                            <p class="text text-center text-danger alert alert-danger">{{ Session::get('fail') }}</p>
                        @endif
                        <div class="form-group">
                            {!! Form::label('category_name','Category Name', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::text('category_name',old('category_name'), ['class'=>'form-control']) !!}
                                <span class="text text-danger">{{ $errors->has('category_name') ? $errors->first('category_name') : '' }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('category_description','Category Description', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::textarea('category_description',old('category_description'), ['class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::label('publication_status','Publication Status', ['class'=>'col-md-3']) !!}
                            <div class="col-md-9">
                                {!! Form::radio('publication_status',1,true) !!} Published
                                {!! Form::radio('publication_status',0) !!} Unpublished
                                @error('publication_status') <span class="text text-danger">{{ $message }}</span>@enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-9">
                                <input type="submit" value="Save Category" class="btn btn-success btn-block" name="saveCategory">
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection