<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Hash;
use Session;
use Mail;
class AdminController extends Controller
{
    public function login(){
        return view('backend.login.login');
    }
    public function userLogin(Request $request){
        $request->validate([
            'email'     => 'required|email',
            'password'  => 'required:min:6'
        ]);
        $adminInfo = Admin::all()->where('email',$request->email)->first();
        if(!$adminInfo){
            return back()->with('fail','We could not recognized your email address.');
        }else{
            if(Hash::check($request->password,$adminInfo->password)){
                $request->Session()->put('userLoggedId',$adminInfo->id);
                $request->Session()->put('LoggedUserName',$adminInfo->first_name.' '.$adminInfo->last_name);
                $data = $adminInfo->toArray();
                Mail::send('mails.login.login',$data,function ($message) use ($data){
                    $message->to($data['email']);
                    $message->subject('Success Login');
                });
                return redirect('/dashboard');
            }else{
                return back()->with('fail','Your Password Not Currect');
            }
        }
    }
    public function register(){
        return view('backend.register.register');
    }
    public function userRegistration(Request $request){
        $request->validate([
            'first_name'        => 'required',
            'last_name'         => 'required',
            'email'             => 'required|email|unique:admins',
            'new_password'      => 'required|same:confirm_password|min:6',
            'confirm_password'  => 'required|same:new_password|min:6'
        ]);
        $admin = New Admin();
        $admin->first_name      = $request->first_name;
        $admin->last_name       = $request->last_name;
        $admin->email           = $request->email;
        $admin->password        = Hash::make($request->confirm_password);
        $save = $admin->save();
        if($save){
            Session::put('adminId',$admin->id);
            Session::put('adminName',$admin->first_name.' '.$admin->last_name);
            $data = $admin->toArray();
            Mail::send('mails.registration.registration',$data,function ($message) use ($data) {
                $message->to($data['email']);
                $message->subject('Registration Confirmation');
            });
            return back()->with('success','Your Registration successfully complete');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function dashboard(){
        return view('backend.dashboard.dashboard');
    }
    public function userLogout(){
        if(Session::get('userLoggedId')){
            Session::pull('userLoggedId');
            Session::pull('LoggedUserName');
            return redirect('/login');
        }else{
            return "Something went wrong please try again.";
        }
    }
}
