<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Brand;
class BrandController extends Controller
{
    public function addBrand(){
        return view('backend.brand.add-brand');
    }
    protected function brandValidation($request){
        $request->validate([
            'brand_name'        => 'required',
            'publication_status'=> 'required'
        ]);
    }
    protected function brandInfo($request){
        $brand = New Brand();
        $brand->brand_name          = $request->brand_name;
        $brand->brand_description   = $request->brand_description;
        $brand->publication_status  = $request->publication_status;
        $save = $brand->save();
        return $save;
    }
    public function saveBrand(Request $request){
        $this->brandValidation($request);
        $save = $this->brandInfo($request);
        if($save){
            return back()->with('success','Your Brand Successfully Added');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function manageBrand(){
        $brands = Brand::all()->sortByDesc('id');
        return view('backend.brand.manage-brand',['brands'=>$brands]);
    }
    public function brandStatus($id,$value){
        $brand = Brand::find($id);
        if($value == 1){
            $brand->publication_status = 0;
        }elseif($value == 0){
            $brand->publication_status = 1;
        }
        $brand->save();
        if($value == 1){
            return back()->with('success','Your Brand Successfully Added');
        }elseif($value == 0){
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function editBrand($id){
        $brand = Brand::find($id);
        return view('backend.brand.edit-brand',['brand'=>$brand]);
    }
    protected function updateBrandInfo($request){
        $brand = Brand::find($request->brand_id);
        $brand->brand_name          = $request->brand_name;
        $brand->brand_description   = $request->brand_description;
        $brand->publication_status  = $request->publication_status;
        $brand = $brand->save();
        return $brand;
    }
    public function updateBrand(Request $request){
        $this->brandValidation($request);
        $brand = $this->updateBrandInfo($request);
        if($brand){
            return back()->with('success','Your Brand Successfully Update');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function brandDelete($id){
        $brand = Brand::find($id);
        $brand->delete();
        return back()->with('success','Your Brand Successfully Delete');
    }
}
