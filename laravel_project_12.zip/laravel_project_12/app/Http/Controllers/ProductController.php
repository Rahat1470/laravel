<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Product;
use Image;
use DB;
class ProductController extends Controller
{
    public function addProduct(){
        $categories = Category::all()->sortByDesc('id');
        $brands = Brand::all()->sortByDesc('id');
        return view('backend.product.add-product',['categories'=>$categories,'brands'=>$brands]);
    }
    protected function productValidation($request){
        $request->validate([
            'product_name'          => 'required',
            'product_slug'          => 'required',
            'category_id'           => 'required',
            'brand_id'              => 'required',
            'product_price'         => 'required',
            'product_quantity'      => 'required'
        ]);
    }protected function updateproductValidation($request){
        $request->validate([
            'product_name'          => 'required',
            'product_slug'          => 'required',
            'category_id'           => 'required',
            'brand_id'              => 'required',
            'product_price'         => 'required',
            'product_quantity'      => 'required'
        ]);
    }
    protected function saveProductInfo($request,$path){
        $product = New Product();
        $product->product_name              = $request->product_name;
        $product->product_slug              = $request->product_slug;
        $product->category_id               = $request->category_id;
        $product->brand_id                  = $request->brand_id;
        $product->product_price             = $request->product_price;
        $product->product_quantity          = $request->product_quantity;
        $product->product_image             = $path;
        $product->product_sort_description  = $request->product_sort_description;
        $product->product_long_description  = $request->product_long_description;
        $product->publication_status        = $request->publication_status;
        $save = $product->save();
        return $save;
    }
    protected function saveProductImage($request){
        if($request->hasfile('product_image')){
            $product_image = $request->file('product_image');
            $image_ext = $product_image->getClientOriginalExtension();
            $image_name = date('d-m-Y-H-i-s-A').'.'.$image_ext;
            $directory = 'product-image/';
            $path = $directory.$image_name;
            Image::make($product_image)->save($path);
            return $path;
        }else{
            $path = "No Image Selected";
            return $path;
        }
    }
    public function saveProduct(Request $request){
        $this->productValidation($request);
        $path = $this->saveProductImage($request);
        $save = $this->saveProductInfo($request,$path);
        if($save){
            return back()->with('success','Your Product Successfully Added.');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function manageProduct(){
        $products = DB::table('products')->join('categories','products.category_id','=','categories.id')
                                         ->join('brands','products.brand_id','=','brands.id')
                                         ->select('products.*','categories.category_name','brands.brand_name')
                                         ->orderBy('id','DESC')
                                         ->get();
        return view('backend.product.manage-product',['products'=>$products]);
    }
    public function productStatus($id,$value){
        $product = Product::find($id);
        if($value == 1){
            $product->publication_status = 0;
        }elseif($value == 0){
            $product->publication_status = 1;
        }
        $product->save();
        if($value == 1){
            return back()->with('fail','Your Product Successfully Unpublished');
        }elseif($value == 0){
            return back()->with('success','Your Product Successfully Published');
        }
    }
    public function editProduct($id){
        $categories = Category::all()->sortByDesc('id');
        $product = Product::find($id);
        $brands = Brand::all()->sortByDesc('id');
        return view('backend.product.edit-product',['product'=>$product,'categories'=>$categories,'brands'=>$brands]);
    }
    protected function updateProductInfoWithImage($product,$request,$path){
        $product = Product::find($request->product_id);
        $product->product_name              = $request->product_name;
        $product->product_slug              = $request->product_slug;
        $product->category_id               = $request->category_id;
        $product->brand_id                  = $request->brand_id;
        $product->product_price             = $request->product_price;
        $product->product_quantity          = $request->product_quantity;
        $product->product_image             = $path;
        $product->product_sort_description  = $request->product_sort_description;
        $product->product_long_description  = $request->product_long_description;
        $product->publication_status        = $request->publication_status;
        $save = $product->save();
        return $save;
    }
    protected function updateProductInfoWithoutImage($product,$request){
        $product = Product::find($request->product_id);
        $product->product_name              = $request->product_name;
        $product->product_slug              = $request->product_slug;
        $product->category_id               = $request->category_id;
        $product->brand_id                  = $request->brand_id;
        $product->product_price             = $request->product_price;
        $product->product_quantity          = $request->product_quantity;
        $product->product_sort_description  = $request->product_sort_description;
        $product->product_long_description  = $request->product_long_description;
        $product->publication_status        = $request->publication_status;
        $save = $product->save();
        return $save;
    }
    public function updateProduct(Request $request){
        $this->productValidation($request);
        $product = Product::find($request->product_id);
        if($request->hasfile('product_image')){
            $path = $this->saveProductImage($request);
            $save = $this->updateProductInfoWithImage($product,$request,$path);
        }else{
            $save = $this->updateProductInfoWithoutImage($product,$request);
        }
        if($save){
            return back()->with('success','Your Product Successfully Update');
        }else{
            return back()->with('fail','Something went wrong. Please try again');
        }
    }
    public function productDelete($id){
        $product = Product::find($id);
        $product->delete();
        return back()->with('success','Your Product Successfully Delete');
    }
    
}