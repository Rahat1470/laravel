<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Cart;
class NewshopController extends Controller
{
    public function index(){
        $products = Product::all();
        return view('front-end.home.home',['products'=>$products]);
    }
    public function categoryPage($id){
        $products = Product::where('category_id',$id)->where('publication_status',1)->get();
        return view('front-end.category.category',['products'=>$products]);
    }
    public function singlProduct($slug){
        $product = Product::all()->where('product_slug',$slug)->first();
        return view('front-end.product.singl-product',['product'=>$product]);
    }
    public function productQuantity(Request $request){
        $product = Product::find($request->product_id);
        Cart::add([
            'id'        => $product->id,
            'name'      => $product->product_name,
            'qty'       => $request->product_quantity,
            'price'     => $product->product_price,
            'weight'    => 550,
            'options'   => [
                'image' => $product->product_image
            ]
        ]);
        return back()->with('success','Your Product Successfully added your cart.');
    }
    public function cartPage(){
        $carts = Cart::content();
        return view('front-end.product.cart',['carts'=>$carts]);
    }
    public function update_qty(Request $request){
        $product = Cart::update($request->product_id,$request->productQuantity);
        return back();
    }
    public function cartDelete($id){
        $product = Cart::remove($id);
        return back();
    }
}
