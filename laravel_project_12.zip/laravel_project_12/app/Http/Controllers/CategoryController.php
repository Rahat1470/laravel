<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
class CategoryController extends Controller
{
    public function addCategory(){
        return view('backend.category.add-category');
    }
    protected function categoryInfoValidation($request){
        $request->validate([
            'category_name'         => 'required',
            'publication_status'    => 'required'
        ]);
    }
    protected function categoryInfo($request){
        $category = New Category();
        $category->category_name        = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publication_status   = $request->publication_status;
        $save = $category->save();
        return $save;
    }
    public function saveCategory(Request $request){
        $this->categoryInfoValidation($request);
        $save = $this->categoryInfo($request);
        if($save){
            return back()->with('success','Your Category Successfully Added');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function manageCategory(){
        $categories = Category::all()->sortByDesc('id');
        return view('backend.category.manage-category',['categories'=>$categories]);
    }
    public function categoryStatus($id,$value){
        $category = Category::find($id);
        if($value == 1){
            $category->publication_status = 0;
        }elseif($value == 0){
            $category->publication_status = 1;
        }
        $category->save();
        if($value == 1){
            return back()->with('fail','Your Category Successfully Unpublished');
        }elseif($value == 0){
            return back()->with('success','Your Category Successfully Published');
        }
    }
    public function editCategory($id){
        $category = Category::find($id);
        return view('backend.category.edit-category',['category'=>$category]);
    }
    protected function categoryUpdateInfo($request){
        $category = Category::find($request->category_id);
        $category->category_name        = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publication_status   = $request->publication_status;
        $update = $category->save();
        return $update;
    }
    public function updateCategory(Request $request){
        $this->categoryInfoValidation($request);
        $update = $this->categoryUpdateInfo($request);
        if($update){
            return back()->with('success','Your Category Successfully Update');
        }else{
            return back()->with('fail','Something went wrong. Please try again.');
        }
    }
    public function categoryDestroy($id){
        $category = Category::find($id);
        $category->delete();
        return back()->with('success','Your Category Successfully Delete');
    }
}
