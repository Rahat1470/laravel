
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="text text-center alert alert-success">Add Category</h2>
                </div>
                <div class="panel-body">
                    <?php echo Form::open(['route'=>'saveCategory','class'=>'form-horizontal']); ?>

                        <?php if(Session::get('success')): ?>
                            <p class="text text-center text-success alert alert-success"><?php echo e(Session::get('success')); ?></p>
                        <?php endif; ?>
                        <?php if(Session::get('fail')): ?>
                            <p class="text text-center text-danger alert alert-danger"><?php echo e(Session::get('fail')); ?></p>
                        <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('category_name','Category Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::text('category_name',old('category_name'), ['class'=>'form-control']); ?>

                                <span class="text text-danger"><?php echo e($errors->has('category_name') ? $errors->first('category_name') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('category_description','Category Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::textarea('category_description',old('category_description'), ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('publication_status','Category Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::radio('publication_status',1,true); ?> Published
                                <?php echo Form::radio('publication_status',0); ?> Unpublished
                                <?php $__errorArgs = ['publication_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-9">
                                <input type="submit" value="Save Category" class="btn btn-success btn-block" name="saveCategory">
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project_12\resources\views/backend/category/add-category.blade.php ENDPATH**/ ?>