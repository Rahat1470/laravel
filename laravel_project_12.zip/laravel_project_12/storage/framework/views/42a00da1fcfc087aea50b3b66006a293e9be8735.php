
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text text-center text-success alert alert-success">Cart Page</h3>
                </div>
                <div class="panel-body">
                    <table class="table table-border">
                        <tr>
                            <th>SI No.</th>
                            <th>Product Name</th>
                            <th>Product Quantity</th>
                            <th>Product Image</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($cart->name); ?></td>
                            <td>
                                <?php echo Form::open(['route'=>'update_qty']); ?>

                                    <?php echo Form::text('productQuantity',$cart->qty, ['class'=>'form-control','min'=>1]); ?>

                                    <?php echo Form::hidden('product_id',$cart->rowId, ['class'=>'form-control']); ?>

                                    <input name="qty_submit" type="submit" value="Update" class="btn btn-success btn-xs">
                                <?php echo Form::close(); ?>

                            </td>
                            <td><img height="100" src="<?php echo e(asset($cart->options->image)); ?>" alt="<?php echo e($cart->name); ?>"></td>
                            <td>
                                <a href="<?php echo e(Route('cartDelete',[$cart->rowId,$cart->name])); ?>"><button class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project_12\resources\views/front-end/product/cart.blade.php ENDPATH**/ ?>