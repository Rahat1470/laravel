
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="h3 text text-center alert alert-success">Manage Category</div>
            </div>
            <?php if(Session::get('success')): ?>
                <p class="text text-center text-success alert alert-success"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>
            <?php if(Session::get('fail')): ?>
                <p class="text text-center text-danger alert alert-danger"><?php echo e(Session::get('fail')); ?></p>
            <?php endif; ?>
            <?php if($categories->count() > 0): ?>
            <table class="table table-border">
                <tr>
                    <th>SI No.</th>
                    <th>Category Name</th>
                    <th>Category Description</th>
                    <th>Category Status</th>
                    <th>Action</th>
                </tr>
                <?php ($i=1); ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($category->category_name); ?></td>
                    <td><?php echo e($category->category_description); ?></td>
                    <td><?php echo e($category->publication_status == 1 ? 'Published' : 'Unpublished'); ?></td>
                    <td>
                        <?php if($category->publication_status == 1): ?>
                            <a href="<?php echo e(Route('categoryStatus',[$category->id,1,$category->category_name])); ?>"><button class="btn btn-success"><i class="fa fa-arrow-up" aria-hidden="true"></i></button></a>
                        <?php else: ?>
                            <a href="<?php echo e(Route('categoryStatus',[$category->id,0,$category->category_name])); ?>"><button class="btn btn-warning"><i class="fa fa-arrow-down" aria-hidden="true"></i></button></a>
                        <?php endif; ?>
                        <a href="<?php echo e(Route('editCategory',[$category->id,$category->category_name])); ?>"><button class="btn btn-info"><i class="fas fa-edit"></i></button></a>
                        <a href="<?php echo e(Route('categoryDestroy',[$category->id,$category->category_name])); ?>"><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
            <h3 class="text text-info alert alert-danger text-center">No Data Found</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project_12\resources\views/backend/category/manage-category.blade.php ENDPATH**/ ?>