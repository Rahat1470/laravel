
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="text text-center alert alert-success">Edit Product</h2>
                </div>
                <div class="panel-body">
                    <?php echo Form::open(['name'=>'edit_product_form','route'=>'updateProduct','class'=>'form-horizontal','files'=>true]); ?>

                        <?php if(Session::get('success')): ?>
                            <p class="text text-center text-success alert alert-success"><?php echo e(Session::get('success')); ?></p>
                        <?php endif; ?>
                        <?php if(Session::get('fail')): ?>
                            <p class="text text-center text-danger alert alert-danger"><?php echo e(Session::get('fail')); ?></p>
                        <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('product_name','Product Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::text('product_name',$product->product_name, ['class'=>'form-control']); ?>

                                <?php echo Form::hidden('product_id',$product->id, ['class'=>'form-control']); ?>

                                <span class="text text-danger"><?php echo e($errors->has('product_name') ? $errors->first('product_name') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_slug','Product Slug', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::text('product_slug',$product->product_slug, ['class'=>'form-control','not-allowed']); ?>

                                <span class="text text-danger"><?php echo e($errors->has('product_slug') ? $errors->first('product_slug') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('category_id','Category Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <select name="category_id" id="" class="form-control">
                                    <option disabled>--Select Option--</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->has('category_id') ? $errors->first('category_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('brand_id','Brand Name', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <select name="brand_id" id="" class="form-control">
                                    <option disabled>--Select Option--</option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->has('brand_id') ? $errors->first('brand_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_price','Product Price', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::text('product_price',$product->product_price, ['class'=>'form-control']); ?>

                                <span class="text text-danger"><?php echo e($errors->has('product_price') ? $errors->first('product_price') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_quantity','Product Quantity', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::text('product_quantity',$product->product_quantity, ['class'=>'form-control']); ?>

                                <span class="text text-danger"><?php echo e($errors->has('product_quantity') ? $errors->first('product_quantity') : ''); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_image','Product Image', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php if($product->product_image == 'No Image Selected'): ?> <span class="text text-danger">No Image Selected</span><?php else: ?><img src="<?php echo e(asset($product->product_image)); ?>" height="100" alt="<?php echo e($product->product_name); ?>"><?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_image','Product Image', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <input type="file" name="product_image" id="" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_sort_description','Product Sort Description', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::textarea('product_sort_description',$product->product_sort_description, ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('product_long_description','Product Long Description', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::textarea('product_long_description',$product->product_long_description, ['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('publication_status','Publication Status', ['class'=>'col-md-3']); ?>

                            <div class="col-md-9">
                                <?php echo Form::radio('publication_status',1,$product->publication_status == 1 ? true : '' ); ?> Published
                                <?php echo Form::radio('publication_status',0,$product->publication_status == 0 ? true : '' ); ?> Unpublished
                                <?php $__errorArgs = ['publication_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-9">
                                <input type="submit" value="Save Product" class="btn btn-success btn-block" name="saveProduct">
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.forms['edit_product_form'].elements['category_id'].value='<?php echo e($product->category_id); ?>';
    document.forms['edit_product_form'].elements['brand_id'].value='<?php echo e($product->brand_id); ?>';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project_12\resources\views/backend/product/edit-product.blade.php ENDPATH**/ ?>